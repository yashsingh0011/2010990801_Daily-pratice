import Banner from "../Components/Banner"
import Footer from "../Components/Footer"
import Freecource from "../Components/Freecource"
import Navbar from "../Components/Navbar"


function Home() {
  return (
   <>
<Navbar/>
<Banner/>
<Freecource/>
<Footer/>
   </>
  )
}

export default Home